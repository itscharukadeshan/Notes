# Sunrise and Sunset

Color Temperature in Kelvin (K): 3,000 to 4,000