# Candle Flame

Color Temperature in Kelvin (K): 1,000 to 2,000