# Cloudy Sky and Shade

Color Temperature in Kelvin (K): 6,500 to 8,000