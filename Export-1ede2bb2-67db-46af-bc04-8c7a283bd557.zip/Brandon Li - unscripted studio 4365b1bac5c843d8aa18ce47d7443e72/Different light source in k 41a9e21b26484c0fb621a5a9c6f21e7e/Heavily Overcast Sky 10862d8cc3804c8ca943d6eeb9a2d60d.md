# Heavily Overcast Sky

Color Temperature in Kelvin (K): 9,000 to 10,000