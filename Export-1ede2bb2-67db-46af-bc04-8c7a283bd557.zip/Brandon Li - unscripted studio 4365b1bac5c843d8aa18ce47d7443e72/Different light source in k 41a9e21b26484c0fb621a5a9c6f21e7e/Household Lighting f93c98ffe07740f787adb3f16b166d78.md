# Household Lighting

Color Temperature in Kelvin (K): 2,500 to 3,500